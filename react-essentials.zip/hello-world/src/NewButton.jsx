export const NewButton = () => {
    return <button className="error">New Button</button>
}