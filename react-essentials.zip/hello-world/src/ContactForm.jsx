export const ContactForm = () => {
    return (
        <form>
            <input type="text" placeholder="Your Name"/>
            <br />
            <input type="text" placeholder="Your Email"/>  
        </form>
    )
}