import styles from "./Alert.module.css"
//import "./Alert.css"
export const Alert = ({children, type = 'success'}) => {
    //return <div style = {{
       // backgroundColor: type==='success'? '#10b981':'#ef4444', 
      //  color:'black',
     //   padding:'16px',
     //   borderRadius:'8px',
     //   marginBottom:"16px"
    //}}>
    //    {children}
  //  </div>
  //return <div className={`alert ${type}`}>{children}</div>
  return <div className={`${styles.alert} ${styles[type]}`}>{children}</div>
}
