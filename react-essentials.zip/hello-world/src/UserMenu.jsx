import { Avatar } from './Avatar'

export const UserMenu = () => {
    return (
        <div>
            <h4>User Menu</h4>
            <Avatar/>
        </div>
    )
}