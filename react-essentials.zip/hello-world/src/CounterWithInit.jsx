import { useReducer } from "react"

const initialCount = 0

const countReducer = (state, action) =>{
    //return new state 
    switch (action){
        case 'increment': return state + 1
        case 'decrement':
            return state - 1
        case 'reset':
            return  initialCount
        default: 
            return state
    } 
}

const init = (initialValue) => {
    console.log('init functoin called - this only runs once')

    const saveCount = localStorage.getItem("count")

    if (saveCount !== null) {
        console.log('Found saved count', saveCount)
        return parseInt(saveCount)

    }
    console.log('No saved value, using initial value: ', initialValue)
    return initialValue
}

export const CounterWithInit = () => {
    
    const [count, dispatch] = useReducer(countReducer, initialCount, init)

    return (
    <div>
        <p>Count: {count}</p>
        <button onClick={() => dispatch('increment')}>Increment</button>
        <button onClick={() => dispatch('decrement')}>Decrement</button>
        <button onClick={() => dispatch('reset')}>Reset</button>
    </div>
    )
}