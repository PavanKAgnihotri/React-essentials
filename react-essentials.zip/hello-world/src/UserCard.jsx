import { UserInfo } from "./UserInfo";

//export const UserCard = ({name, age, city, email}) => {
//export const UserCard = (props) => {
export const UserCard = ({id, ...rest}) => {
    return (
        <div>
            <h2> User {id} Details</h2>
            <UserInfo name = {name} age={age} city={city} email={email}/>
            <UserInfo {...props}/>
            <UserInfo {...rest}/>
        </div>
    )
}