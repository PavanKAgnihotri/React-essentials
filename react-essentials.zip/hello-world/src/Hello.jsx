import React from 'react'
export const Hello = () => {
    return (<div>
        <h1>Hello, Pavan!</h1>
    </div>
    );
};

export const HelloWithoutJSX = () => {
    return React.createElement("div", { id: "container" }, React.createElement("h1", null, "Hello, Pavan!"));
};