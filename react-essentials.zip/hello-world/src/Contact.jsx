import { ActionButton } from "./AcrionButton"
export const Contact = () => {
    
    const handleMessage = () => {
        alert('sending your message')
    } 
    return (
        <div>
            <h2> Contact Us</h2>
            <ActionButton text = "send message" onClick={handleMessage}/>
        </div>
    )
}