export const CustomButton = ({ text }) => {
    const name = "Rocky"
    // const handleClick = () =>{
    //     alert("Thanks for liking") 
    // }
    const handleClick = () =>{
        console.log(`Hey ${name}, you clicked ${text}`)
        alert("Thanks for liking") 
    }
    // const handleClick = ( e ) =>{
    //     console.log("clicked element", e.target)
    //     console.log("click coordinates", e.clientX, e.clientY)
    //     console.log("Which mouse button?", e.button)
    //     alert("Thanks for liking") 
    // }
    return <button onClick={handleClick}>{text}</button>
    //return <button onClick={() => alert("Thanks for Liking!!")}>Like</button>
}