export const UserProfile = () => {
    return (
        <>
        <h1>XYZ</h1>
        <p>Author: Pavan</p>
        </>
    )
}