import { useState } from 'react'
//import reactLogo from './assets/react.svg'
//import viteLogo from '/vite.svg'
import './App.css'
import { Welcome } from "./Welcome"
import  Button  from "./Button"
import { Hello, HelloWithoutJSX } from "./Hello"
import { UserProfile } from './UserProfile'
import { ContactForm } from './ContactForm'
import { StyledForm } from './StyledForm'
import { CandidateProfile } from './CandidateProfile'
import { Product } from './Product'
import { Greeting } from './Greeting'
import { CardWrapper } from './CardWrapper'
import { UserDetails } from './UserDetails'
import { ProductList } from './ProductList'
import { NameList } from './NameList'
import { TodoList } from './TodoList'
import { Alert } from './Alert'
import { NewButton } from './NewButton'
import { CustomButton } from './CustomButton'
import { Contact } from './Contact'
import { NewsLetter } from './NewsLetter'
import { Menu } from './Menu'
import { Counter } from './Counter'
import { LoginCard } from './LoginCard'
import { SimpleCounter } from './SimpleCounter'
import { PreviousStateCounter } from './PreviousStateCounter'
import { BatchingCounter } from './BatchingCounter'
import { UserProfiles } from './UserProfiles'
import { TodoLists } from './ToDoLists'
import { ShoppingCart } from './ShoppingCart'
import { CounterWithReducer } from './CounterWithReducer'
import { ShoppingCartWithReducer } from './ShoppingCartWithReducer'
import { CounterWithInit } from './CounterWithInit'
import { CustomCounter } from './CustomCounter'
import { Header } from './Header'
import { UserContext } from './UserContext'
import { UserContextProvider } from './UserContextProvider'
import { StopWatch } from './StopWatch'
import { FocusInput } from './FocusInput'
function App() {
  //const [count, setCount] = useState(0)
  
  return (
  //<UserContextProvider> 
    <div>
      <h1>Dashboard</h1> 
      <FocusInput/>
  
   {/*
   <StopWatch/>
    <Header/>
   <CustomCounter/>
   <CounterWithInit/>
   <ShoppingCartWithReducer/>
   <CounterWithReducer/>
   <ShoppingCart/>
   <TodoLists/>
    <UserProfiles/>
   <BatchingCounter/>
   <PreviousStateCounter/>
    {/*<SimpleCounter/>/}

    {/* <LoginCard/>
    <Counter/>
    <Menu/>
    <Contact/>
    <NewsLetter/>
    <CustomButton text = "Like"/>
    <CustomButton text = "Bookmark"/>
    <Alert> Your changes have been saved</Alert>
    <Alert type="error"> SOmething went wrong</Alert>
    <NewButton/>
    <TodoList/>
    <NameList/>
    <ProductList/>
    <UserDetails name="Bruce Wayne" isOnline={true} hideOffline={false} isPremium={true} isNewUser={true} role="admin"/>
    <UserDetails name="Clark kent" isOnline={true} hideOffline={true} role="vip"/>
    <CardWrapper title='Simple card'>
      <p>Bruce</p>
      <p>batman@asi.com</p>
      <button>Edit profile</button>

    </CardWrapper>

    <Greeting name="Bruce" message='Good morning'/>
    <Greeting name='Clark'/>
    <Greeting message='Bye'/>
    <Greeting />

    <Product title="Gaming Laptop" price = {1299} inStock = {true} categories= {["elec", "game", "comp"]}/>
    <CandidateProfile/>
    <StyledForm/>
    <ContactForm />
    <UserProfile />
    <Hello />
    <HelloWithoutJSX />
    <Welcome name="Bruce" alias = "batman"/>
    <Welcome name="Clark" alias = "superman"/>
    
    <Button /> 
    </UserContextProvider>*/}
    
    </div>
  
  )
}

export default App
