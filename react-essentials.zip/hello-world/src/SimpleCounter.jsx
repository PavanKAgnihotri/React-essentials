import { useState } from "react"

export const SimpleCounter = () => {
    
    const [count, setCount] = useState(0)
    console.log('Render Phase: component rendering with count = ', count)

    // const handleClick = () => {
    //     console.log("Before setCount, count is: ", count)
    //     setCount(count+1)
    //     console.log("Still in Trigger phase. After setCount, count is: ", count)
    // }

    const handleClick = () => {
        setCount(count+1)
        console.log("After setCount(Count+1), count is: ", count)
        setCount(count+5)
        console.log("After setCount(Count+5), count is: ", count)
        setCount(count+10)
        console.log("After setCount(Count+10), count is: ", count)
        setTimeout(() => {
            console.log("AFter 2 seconds, count is: ", count)
        }, 2000)
    }
    return (
        <div>
            <h2>Count: {count}</h2>
            <button onClick={() => setCount(count+1)}>Increment</button>
            <button onClick={handleClick}>Incrementnew</button>
        </div>
    )
}