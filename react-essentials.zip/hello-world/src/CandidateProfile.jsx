export const CandidateProfile = () =>{
    const name = "Peter Parker";
    const role = "Web developer";
    const yoe = 5;
    const isAvailable = true;
    return (
        <>
        <h2>{name}</h2>
        <p>{role} with a {yoe} years of experience</p>
        <p>Started in {2026 - yoe }</p>
        <p>Status: {isAvailable?"Available for Hire":"not vailable"}</p>
        <p>COntactEmail: {name.toLowerCase().replace(" ",".")}@email.com</p>
        </>
    )

}