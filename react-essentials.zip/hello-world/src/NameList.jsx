export const NameList = () => {
    const names = ['Bruce', 'Clark', 'Diana']
    
    const nameList = names.map((n, index) => <h2 key = {index}> {index} {n}</h2>)

    return <div>{nameList}</div>
}