import { useState } from "react"

export const UserProfiles = () => {
    const [user, setUser] = useState({
        name: "Bruce Wayne",
        age: 30,
        email: "batman@email.com",
        address: {
            city: "Gotham city",
            country: "USA"
        }
    })

    console.log("Component rendering, user: ", user)
    const updateName = () =>{
        setUser({
            ...user,
            name:"Clark Kent"
        })
    }
    const updateAge = () =>{
        setUser({
            ...user,
            age: user.age+1
        })
    }
    const updateMultiplr = () => {
        setUser({
            ...user,
            name:"Clark Kent",
            age: user.age+1
        })
    }

    const updateCity = () => {
        setUser({
            ...user,
            address: {
                ...user.address,
                city: "Metropolis"}
    })
    }

    return (
    <div>
        <h2>{user.name}</h2>
        <p>Age: {user.age}</p>
        <p>Email: {user.email}</p>
        <p>City: {user.address.city}</p>
        <p>Country: {user.address.country}</p>
        <button onClick={updateName}>Change name to clark kent</button>
        <button onClick={updateAge}>Increase Age by 1</button>
        <button onClick={updateMultiplr}>Update name and age</button>
        <button onClick={updateCity}>MOve to Metropolis</button>
    </div>
    )
}