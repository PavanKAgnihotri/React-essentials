import React from "react";
export const ProductList = () => {
    const product = [{id: 1, name: "Laptop", price: 1299},
                    {id: 2, name: "Phone", price: 499},
                    {id: 3, name: "Tablet", price: 699}, {id: 4, name: "headphone", price: 200}]

    const productelements = product.filter((p) => {
        return p.price >500;}).map((p) => {
            return (
                <React.Fragment key = {product.id}>
                <div key = {p.id}>
                    <h3>{p.name}</h3>
                    <p>Price: ${p.price}</p>
                </div>
                </React.Fragment>
            )
        });

    return (
    <div> 
        <h3> Our Products</h3>
        {productelements}
    </div>
    )

};