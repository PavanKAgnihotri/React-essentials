export const UserDetails = ({ name, isOnline, hideOffline, isPremium, isNewUser, role}) => {
    if (hideOffline && !isOnline){
        return null;
    }
    let rolebadge = null;
    if (role==='admin'){
        rolebadge = <span>Admin</span>
    } else if (role === 'moderator'){
        rolebadge = <span> Moderator</span>
    } else if (role === 'vip'){
        rolebadge = <span>VIP</span>
    }

    return (
        <div>
            <h3>{name}
                {isPremium && <span>*</span>}
                {isNewUser && <span>$</span>}
                {rolebadge}
            </h3>
            <span>{isOnline ? "Online":"Offline"}</span>
            <p>{isOnline ? "Available":"Not Available"}</p>
            {isOnline ? (<button>Send Message</button>): (<small>Check back later</small>)}
        </div>
    );
};