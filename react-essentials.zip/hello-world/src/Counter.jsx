import { useState } from "react"

export const Counter = () => {

    //const [count, setCount] = useState(0) //array destructuring
    const [count, setCount] = useState(() => {
        console.log('initial state function called')
        return 0
    }) //array destructuring
    //counterValue, setterFunction = useState (initial state)
    //const count = 0
    //console.log("Counter component resndered with count:", count)
    const handleClick = () => {
        setCount(count+1)
        //count = count+1 
        //console.log(count) 
    }
    return <button onClick={handleClick}>Count: {count}</button>
}