import { useState } from "react"
export const USerDashboard = ({isPremium}) => {
    const [credits, setCredits] = useState(100)
    if(!isPremium){
        return <div> Upgrade to premium to see Credits</div>
    }
    return <div>
        <p>You have {credits} credits</p>
        <button onClick={()=> setCredits(0)}>Use All Credits</button>
        </div>
}