import { useState } from "react"

export const ShoppingCart = () => {
    const [cartItems, setCartitems] = useState({
        reactcourse: 0,
        vuecourse: 0
    })

    const prices = {
        reactcourse: 49.99,
        vuecourse: 39.99
    }

    const handleAddReactCourse = ()=> {
        if (cartItems.reactcourse<5) {
        setCartitems({
            ...cartItems,
            reactcourse: cartItems.reactcourse+1
        })
    }
    }

    const handleAddVueCourse = () => {
        setCartitems({
            ...cartItems,
            vuecourse: cartItems.vuecourse+1
        })
    }

    const clearCart = ()=>{
        setCartitems({
            reactcourse:0,
            vuecourse: 0
        })
    }

     return (
        <div>
            <h2>Shopping Cart component</h2>
            <ProductCart 
            name='React Course'
            price= {prices.reactcourse}
            quantity={cartItems.reactcourse}
            onAddCart={handleAddReactCourse}/>
            <ProductCart 
            name='Vue Course'
            price= {prices.vuecourse}
            quantity={cartItems.vuecourse}
            onAddCart={handleAddVueCourse}/>
            <CartSummary cartItems={cartItems}
            prices={prices}/>
            <button onClick={clearCart}>Clear Cart</button>
        </div>
     )
}

// export const ProductCart = () => {
//     const [quantity, setQuantity] = useState(0)

//     return (
//         <div>
//             <h3>React Course</h3>
//             <p>$49.99</p>
//             <p>Quantity: {quantity}</p>
//             <button onClick={()=> setQuantity(quantity+1)}>Add to cart</button>
//         </div>
//     )

// }

export const ProductCart = ({name, price, quantity, onAddCart}) => {

    return (
        <div>
            <h3>{name}</h3>
            <p>${price}</p>
            <p>Quantity: {quantity}</p>
            <button onClick={onAddCart}>Add to cart</button>
        </div>
    )

}

export const CartSummary = ({ cartItems, prices}) => {

    const totalItems = cartItems.reactcourse+cartItems.vuecourse
    const totalPrice = cartItems.reactcourse * prices.reactcourse + cartItems.vuecourse * prices.vuecourse
    return (
        <div>
            <h3>Cart Summary</h3>
            <p>Total items: {totalItems}</p>
            <p>Total price: ${totalPrice.toFixed(2)}</p>
        </div>
    )
}