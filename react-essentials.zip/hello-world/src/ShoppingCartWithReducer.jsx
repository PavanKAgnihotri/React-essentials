import { useReducer } from "react"

const initialState = {
    items: [], //{id, name, price, quantity}
    totalAmount: 0,
    totalItems: 0
}

const reducer = (state, action) => {
    //return new state
    switch (action.type) {
        case "ADD_ITEM": {
            const existingItemIndex = state.items.findIndex(
                item => item.id === action.payload.id
            )
            let updatedItem;
            if (existingItemIndex>=0){
                updatedItem = [...state.items]
                updatedItem[existingItemIndex] = {
                    ...updatedItem[existingItemIndex],
                    quantity: updatedItem[existingItemIndex].quantity + 1
                }
            }
            else {
                updatedItem = [
                    ...state.items,
                    {
                        ...action.payload,
                        quantity: 1
                    }
                ]
            }
            return {
                ...state,
                items: updatedItem,
                totalAmount: updatedItem.reduce(
                    (total, item) => total + item.price * item.quantity,
                    0
                ),
                totalItems: updatedItem.reduce(
                    (total, item) => total + item.quantity, 0
                )
            }
        }
        case 'REMOVE_ITEM':{
            const filteredItems = state.items.filter(
                (item) => item.id !== action.payload.id
            )
            return {
                ...state,
                items: filteredItems,
                totalAmount: filteredItems.reduce(
                    (total, item) => total + item.price * item.quantity,
                    0
                ),
                totalItems: filteredItems.reduce(
                    (total, item) => total + item.quantity, 0
                )
            }
        }
        case 'UPDATE_QUANTITY':{
            if(action.payload.quantity===0){
                return reducer(state, {
                    type: 'REMOVE_ITEM',
                    payload: {id: action.payload.id}
                })
            }
            const updatedQuantityItems = state.items.map((item) => 
            item.id === action.payload.id ? {...items, quantity: action.payload.quantity} : item 
            )
            return {
                ...state,
                items: updatedQuantityItems, 
                totalAmount: updatedQuantityItems.reduce(
                    (total, item) => total + item.price * item.quantity,
                    0
                ),
                totalItems: updatedQuantityItems.reduce(
                    (total, item) => total + item.quantity, 0
                )
            }
        }
        case 'CLEAR_CART':
            return initialState
        default: 
            return state
    }
}

export const ShoppingCartWithReducer = () => {
    
    const [state, dispatch] = useReducer(reducer, initialState)
    const products = [
        {id:1, name: 'React Course', price: 49.99},
        {id:1, name: 'node.js Course', price: 39.99},
        {id:1, name: 'Javascript Bundle', price: 89.99}
    ]
    
    
    return (
    <div>
        <h2>Products</h2>
        {
            products.map((product) => (
                <div key={product.id}> 
                <h3>{product.name} - ${product.price}</h3>
                <button onClick={() => dispatch({
                    type: 'ADD_ITEM',
                    payload: product
                })}>Add to Cart</button>
                </div>
            )
        )}

        <div>
            <h2>Shopping cart</h2>
            {state.items.length === 0 ? (<p>Your cart is empty</p>) : (
                <div>
                    {
                        state.items.map((item)=>(
                            <div key={item.id}>
                                <p>
                                    {item.name} - ${item.price} x {item.quantity}
                                </p>
                                <button onClick={() => dispatch({
                                    type: 'UPDATE_QUANTITY', payload: { id: item.id, quantity: item.quantity-1}
                                })}>-</button>
                                <button onClick={() => dispatch({
                                    type: 'UPDATE_QUANTITY', payload: { id: item.id, quantity: item.quantity+1}
                                })}>+</button>
                                <button onClick={() => dispatch({type:'REMOVE_ITEM',
                                    payload: {id: item.id} }
                                )}>Remove</button>
                            </div>
                        ))
                    }
                </div>
            )}
            <h3>Total items: {state.totalItems}</h3>
            <h3>Total Amount: {state.totalAmount.toFixed(2)}</h3>
            {
                state.items.length>0 && (
                    <button onClick={() => dispatch({type:'CLEAR_CART'})}>Clear Cart</button>
                )
            }
        </div>
    </div>
    )
}