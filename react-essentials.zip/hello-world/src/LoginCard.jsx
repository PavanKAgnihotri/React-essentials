import { useState } from "react"
export const LoginCard = () => {
    const [isLoggedIn, setisLoggedIn] =  useState(false)
    
    const [Message, setMessage] = useState("")

    const handleLogin = () => {
        setisLoggedIn(!isLoggedIn)
    }

    const handleChange = () => {
        setMessage(event.target.value)
    }
    return (
        <>
        <button onClick={handleLogin}>{isLoggedIn ? "Logout" : "LogIn"} </button>
        <div>
            <input type = "text" placeholder="Type a message" value = {Message} onChange={handleChange}/>
            <p>{Message}</p>
        </div>
        </>
    )
}